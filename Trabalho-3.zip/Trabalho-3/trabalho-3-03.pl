cidade_pais(brasilia, brasil).
cidade_pais(londres, reino_unido).
cidade_pais(roma, italia).
cidade_pais(paris, franca).
cidade_pais(toronto, canada).
cidade_pais(toquio, japao).
cidade_pais(sydney, australia).
cidade_pais(cairo, egito).
cidade_pais(estados_unidos, nova_york).
cidade_pais(dubai, emirados_arabes).


%Regra para encontrar todas as cidades em um determinado pa�s
cidades_no_pais(Pais, Cidades) :-
    findall(Cidade, cidade_pais(Cidade, Pais), Cidades).
