% Defini��o dos fatos (alunos e notas)
nota_aluno(joao, 8).
nota_aluno(maria, 6).
nota_aluno(pedro, 4).
nota_aluno(ana, 7).
nota_aluno(lucas, 5).
nota_aluno(sara, 3).
nota_aluno(andre, 9).
nota_aluno(carla, 2).
nota_aluno(marcos, 6).
nota_aluno(julia, 5).

% Regra para determinar se um aluno foi aprovado na disciplina (nota maior ou igual a 5)
aprovado(Aluno) :-
    nota_aluno(Aluno, Nota),
    Nota >= 5.
