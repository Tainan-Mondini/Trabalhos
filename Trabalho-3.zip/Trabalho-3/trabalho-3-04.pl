% Defini��o dos fatos (produtos, pre�os e estoque)
produto_estoque(teclado, 25, 5).
produto_estoque(monitor, 150, 3).
produto_estoque(maouse, 12, 0).
produto_estoque(caderno, 5, 8).
produto_estoque(caneta, 1, 20).
produto_estoque(lapis, 0.5, 15).
produto_estoque(borracha, 0.8, 3).
produto_estoque(agendas, 7, 0).
produto_estoque(celular, 300, 2).
produto_estoque(headphones, 20, 7).

% Regra para determinar se um produto est� em falta (quantidade em estoque igual a 0)
em_falta(Produto) :-
    produto_estoque(Produto, _, Quantidade),
    Quantidade =:= 0.
