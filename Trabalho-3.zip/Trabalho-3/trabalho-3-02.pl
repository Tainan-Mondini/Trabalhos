cor_objeto(vermelho, ma��).
cor_objeto(azul, caneta).
cor_objeto(verde, caderno).
cor_objeto(amarelo, l�pis).
cor_objeto(verde, folha).
cor_objeto(rosa, caderno).
cor_objeto(preto, livro).
cor_objeto(branco, borracha).
cor_objeto(azul, pasta).
cor_objeto(verde, marcador).

cor_associada(Cor) :-
    cor_objeto(Cor, _).

:- cor_associada(verde),
   write('A cor verde est� associada a algum objeto.').
