% Defini��o dos fatos (m�sicas e g�neros)
musica_genero('Bohemian Rhapsody', rock).
musica_genero('Shape of You', pop).
musica_genero('Smooth', latin).
musica_genero('Stairway to Heaven', rock).
musica_genero('Despacito', latin).
musica_genero('Thinking Out Loud', pop).
musica_genero('Hotel California', rock).
musica_genero('Dance Monkey', pop).
musica_genero('La Tortura', latin).
musica_genero('Sweet Child O� Mine', rock).

% Regra para listar todas as m�sicas de um g�nero espec�fico
musicas_do_genero(Genero, Musicas) :-
    findall(Musica, musica_genero(Musica, Genero), Musicas).
