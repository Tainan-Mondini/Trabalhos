% Defini��o dos fatos (ingredientes e receitas)
receita(estrogonofe, [carne, creme_de_leite, champignon, cebola, mostarda]).
receita(pizza, [massa_de_pizza, molho_de_tomate, queijo, pepperoni, cebola]).
receita(bolo_de_cenoura, [cenoura, farinha, a�ucar, ovos, oleo_vegetal, fermento]).
receita(salada_cesar, [alface, frango_grelhado, croutons, queijo_parmesao, molho_cesar]).
receita(sopa_de_cebola, [cebola, caldo_de_carne, queijo_gorgonzola, pao, manteiga]).
receita(torta_de_macas, [macas, farinha, manteiga, a�ucar, canela, limao]).
receita(omelete, [ovos, queijo, tomate, cebola, pimentao]).
receita(mousse_de_chocolate, [chocolate, creme_de_leite, ovos, a�ucar, manteiga]).
receita(panqueca, [farinha, ovos, leite, manteiga, chocolate]).
receita(arroz_de_camarao, [arroz, camarao, pimentao, cebola, tomate]).

% Regra para listar todas as receitas que contenham um ingrediente espec�fico
receitas_com_ingrediente(Ingrediente, Receitas) :-
    findall(Receita, (receita(Receita, Ingredientes), member(Ingrediente, Ingredientes)), Receitas).

