% Defini��o dos fatos (pa�ses, capitais e l�nguas oficiais)
pais_capital_lingua(brasil, brasilia, portugues).
pais_capital_lingua(eua, washington, ingles).
pais_capital_lingua(canada, ottawa, ingles).
pais_capital_lingua(argentina, buenos_aires, espanhol).
pais_capital_lingua(franca, paris, frances).
pais_capital_lingua(alemanha, berlim, alemao).
pais_capital_lingua(japao, toquio, japones).
pais_capital_lingua(china, pequim, chines).
pais_capital_lingua(russia, moscou, russo).
pais_capital_lingua(india, nova_delhi, hindi).

% Regra para encontrar todos os pa�ses onde uma l�ngua espec�fica � falada
paises_com_lingua(Lingua, Paises) :-
    findall(Pais, pais_capital_lingua(Pais, _, Lingua), Paises).



