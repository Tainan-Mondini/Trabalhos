idade(joao, 25).
idade(maria, 40).
idade(pedro, 35).
idade(ana, 28).
idade(lucas, 31).
idade(sara, 22).
idade(andre, 33).
idade(carla, 29).
idade(marcos, 45).
idade(julia, 26).

% Regra para verificar se uma pessoa tem mais de 30 anos
mais_de_30_anos(Nome) :-
    idade(Nome, Idade),
    Idade > 30.

% Consulta para listar pessoas com mais de 30 anos
:- findall(Pessoa, mais_de_30_anos(Pessoa), PessoasMaisDe30),
   write('Pessoas com mais de 30 anos: '), write(PessoasMaisDe30), nl.
idade(joao, 25).
idade(maria, 40).
idade(pedro, 35).
idade(ana, 28).
idade(lucas, 31).
idade(sara, 22).
idade(andre, 33).
idade(carla, 29).
idade(marcos, 45).
idade(julia, 26).

% Regra para verificar se uma pessoa tem mais de 30 anos
mais_de_30_anos(Nome) :-
    idade(Nome, Idade),
    Idade > 30.

% Consulta para listar pessoas com mais de 30 anos
:- findall(Pessoa, mais_de_30_anos(Pessoa), PessoasMaisDe30),
   write('Pessoas com mais de 30 anos: '), write(PessoasMaisDe30), nl.
idade(joao, 25).
idade(maria, 40).
idade(pedro, 35).
idade(ana, 28).
idade(lucas, 31).
idade(sara, 22).
idade(andre, 33).
idade(carla, 29).
idade(marcos, 45).
idade(julia, 26).

% Regra para verificar se uma pessoa tem mais de 30 anos
mais_de_30_anos(Nome) :-
    idade(Nome, Idade),
    Idade > 30.

% Consulta para listar pessoas com mais de 30 anos
:- findall(Pessoa, mais_de_30_anos(Pessoa), PessoasMaisDe30),
   write('Pessoas com mais de 30 anos: '), write(PessoasMaisDe30), nl.
% Defini��o dos fatos (cidades e dist�ncias)
distancia_entre_cidades(cidade_a, cidade_b, 50).
distancia_entre_cidades(cidade_a, cidade_c, 80).
distancia_entre_cidades(cidade_a, cidade_d, 120).
distancia_entre_cidades(cidade_a, cidade_e, 90).
distancia_entre_cidades(cidade_a, cidade_f, 110).
distancia_entre_cidades(cidade_a, cidade_g, 70).
distancia_entre_cidades(cidade_a, cidade_h, 130).
distancia_entre_cidades(cidade_a, cidade_i, 95).
distancia_entre_cidades(cidade_a, cidade_j, 60).
distancia_entre_cidades(cidade_a, cidade_k, 100).

% Regra para encontrar a cidade mais pr�xima a uma cidade de origem
cidade_mais_proxima(CidadeOrigem, CidadeMaisProxima, DistanciaMinima) :-
    distancia_entre_cidades(CidadeOrigem, CidadeMaisProxima, DistanciaMinima),
    \+ (distancia_entre_cidades(CidadeOrigem, _, OutraDistancia),
        OutraDistancia < DistanciaMinima).
