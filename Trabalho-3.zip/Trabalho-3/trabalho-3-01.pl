% Defini��o dos fatos
idade(joao, 25).
idade(maria, 40).
idade(pedro, 35).
idade(ana, 28).
idade(lucas, 31).
idade(sara, 22).
idade(andre, 33).
idade(carla, 29).
idade(marcos, 45).
idade(julia, 26).

% Regra para verificar se uma pessoa tem mais de 30 anos
mais_de_30_anos(Nome) :-
    idade(Nome, Idade),
    Idade > 30.

% Consulta para listar pessoas com mais de 30 anos
:- findall(Pessoa, mais_de_30_anos(Pessoa), PessoasMaisDe30),
   write('Pessoas com mais de 30 anos: '), write(PessoasMaisDe30), nl.
