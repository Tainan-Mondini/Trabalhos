% Defini��o dos fatos (animais e esp�cies)
animal_especie(leao, mamifero).
animal_especie(zebra, mamifero).
animal_especie(girafa, mamifero).
animal_especie(elefante, mamifero).
animal_especie(macaco, mamifero).
animal_especie(tigre, mamifero).
animal_especie(pinguim, ave).
animal_especie(coruja, ave).
animal_especie(aguia, ave).
animal_especie(crocodilo, reptil).

% Regra para encontrar todos os animais de uma esp�cie espec�fica
animais_da_especie(Especie, Animais) :-
    findall(Animal, animal_especie(Animal, Especie), Animais).
