<?php
interface EstrategiaOrdenacao {
    public function ordenar(array $lista): array;
}

class BubbleSort implements EstrategiaOrdenacao {
    public function ordenar(array $lista): array {
        $n = count($lista);
        for ($i = 0; $i < $n - 1; $i++) {
            for ($j = 0; $j < $n - $i - 1; $j++) {
                if ($lista[$j] > $lista[$j + 1]) {
                    $temp = $lista[$j];
                    $lista[$j] = $lista[$j + 1];
                    $lista[$j + 1] = $temp;
                }
            }
        }
        return $lista;
    }
}

class QuickSort implements EstrategiaOrdenacao {
    public function ordenar(array $lista): array {
        if (count($lista) <= 1) {
            return $lista;
        }

        $pivot = $lista[0];
        $esquerda = $direita = [];

        for ($i = 1; $i < count($lista); $i++) {
            if ($lista[$i] < $pivot) {
                $esquerda[] = $lista[$i];
            } else {
                $direita[] = $lista[$i];
            }
        }

        return array_merge($this->ordenar($esquerda), [$pivot], $this->ordenar($direita));
    }
}
class OrdenacaoContexto {
    protected $estrategia;

    public function __construct(EstrategiaOrdenacao $estrategia) {
        $this->estrategia = $estrategia;
    }

    public function setEstrategia(EstrategiaOrdenacao $estrategia) {
        $this->estrategia = $estrategia;
    }

    public function ordenarLista(array $lista): array {
        return $this->estrategia->ordenar($lista);
    }
}

// Utilização das estratégias

$contexto = new OrdenacaoContexto(new BubbleSort());

$lista = [3, 1, 5, 2, 4];

echo "Lista original: " . implode(", ", $lista) . "\n";

$listaOrdenada = $contexto->ordenarLista($lista);
echo "Lista ordenada com BubbleSort: " . implode(", ", $listaOrdenada) . "\n";

$contexto->setEstrategia(new QuickSort());

$listaOrdenada = $contexto->ordenarLista($lista);
echo "Lista ordenada com QuickSort: " . implode(", ", $listaOrdenada) . "\n";
