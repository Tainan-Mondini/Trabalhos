<?php
interface Subject {
    public function registrarObserver(Observer $observer);
    public function removerObserver(Observer $observer);
    public function notificarObservers();
}

interface Observer {
    public function atualizar(string $mensagem);
}

class SistemaNotificacao implements Subject {
    private $observadores = [];
    private $ultimaAtualizacao = "";

    public function registrarObserver(Observer $observador) {
        $this->observadores[] = $observador;
    }

    public function removerObserver(Observer $observador) {
        $index = array_search($observador, $this->observadores);
        if ($index !== false) {
            array_splice($this->observadores, $index, 1);
        }
    }

    public function notificarObservers() {
        foreach ($this->observadores as $observador) {
            $observador->atualizar($this->ultimaAtualizacao);
        }
    }

    public function enviarNotificacao(string $mensagem) {
        $this->ultimaAtualizacao = $mensagem;
        $this->notificarObservers();
    }
}

class Usuario implements Observer {
    private $nome;

    public function __construct(string $nome) {
        $this->nome = $nome;
    }

    public function atualizar(string $mensagem) {
        echo "Usuário {$this->nome} recebeu a seguinte notificação: {$mensagem}\n";
    }
}

// Utilização das classes

$sistemaNotificacao = new SistemaNotificacao();

$usuario1 = new Usuario("Alice");
$usuario2 = new Usuario("Bob");
$usuario3 = new Usuario("Carol");

$sistemaNotificacao->registrarObserver($usuario1);
$sistemaNotificacao->registrarObserver($usuario2);
$sistemaNotificacao->registrarObserver($usuario3);

$sistemaNotificacao->enviarNotificacao("Nova atualização disponível!");

$sistemaNotificacao->removerObserver($usuario2);

$sistemaNotificacao->enviarNotificacao("Agora com um usuário removido!");
?>
