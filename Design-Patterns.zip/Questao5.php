<?php
interface FormaGeometrica {
    public function calcularArea(): float;
}

class Circulo implements FormaGeometrica {
    private $raio;

    public function __construct(float $raio) {
        $this->raio = $raio;
    }

    public function calcularArea(): float {
        return pi() * pow($this->raio, 2);
    }
}

class Quadrado implements FormaGeometrica {
    private $lado;

    public function __construct(float $lado) {
        $this->lado = $lado;
    }

    public function calcularArea(): float {
        return pow($this->lado, 2);
    }
}

interface FabricaFormas {
    public function criarForma(): FormaGeometrica;
}

class FabricaCirculo implements FabricaFormas {
    private $raio;

    public function __construct(float $raio) {
        $this->raio = $raio;
    }

    public function criarForma(): FormaGeometrica {
        return new Circulo($this->raio);
    }
}

class FabricaQuadrado implements FabricaFormas {
    private $lado;

    public function __construct(float $lado) {
        $this->lado = $lado;
    }

    public function criarForma(): FormaGeometrica {
        return new Quadrado($this->lado);
    }
}

// Utilização das classes

$fabricaCirculo = new FabricaCirculo(5);
$circulo = $fabricaCirculo->criarForma();
echo "Área do círculo: " . $circulo->calcularArea() . "\n";

$fabricaQuadrado = new FabricaQuadrado(4);
$quadrado = $fabricaQuadrado->criarForma();
echo "Área do quadrado: " . $quadrado->calcularArea() . "\n";
?>
