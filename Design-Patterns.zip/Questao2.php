<?php
interface Relatorio {
    public function gerar();
}
class RelatorioBase implements Relatorio {
    public function gerar() {
        echo "Relatório base gerado.\n";
    }
}
class FormatacaoNegrito implements Relatorio {
    protected $relatorio;

    public function __construct(Relatorio $relatorio) {
        $this->relatorio = $relatorio;
    }

    public function gerar() {
        echo "=== Relatório em Negrito ===\n";
        $this->relatorio->gerar();
    }
}

class FormatacaoItalico implements Relatorio {
    protected $relatorio;

    public function __construct(Relatorio $relatorio) {
        $this->relatorio = $relatorio;
    }

    public function gerar() {
        echo "=== Relatório em Italico ===\n";
        $this->relatorio->gerar();
    }
}

// Criando um relatório base
$relatorioBase = new RelatorioBase();

// Adicionando formatação de negrito ao relatório base
$relatorioNegrito = new FormatacaoNegrito($relatorioBase);
$relatorioNegrito->gerar();

// Adicionando formatação de itálico ao relatório base
$relatorioItalico = new FormatacaoItalico($relatorioBase);
$relatorioItalico->gerar();

// Adicionando formatação de negrito e itálico ao relatório base
$relatorioNegritoItalico = new FormatacaoNegrito(new FormatacaoItalico($relatorioBase));
$relatorioNegritoItalico->gerar();
