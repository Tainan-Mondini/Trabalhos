<?php
class RegistroUsuarios {
    private static $instancia;
    private $usuarios = [];

    private function __construct() {
        // Impede a criação de instâncias diretamente fora desta classe
    }

    public static function obterInstancia(): RegistroUsuarios {
        if (self::$instancia === null) {
            self::$instancia = new self();
        }
        return self::$instancia;
    }

    public function adicionarUsuario($nome, $email) {
        $this->usuarios[] = ['nome' => $nome, 'email' => $email];
    }

    public function listarUsuarios() {
        return $this->usuarios;
    }
}

// Criando instâncias e adicionando usuários
$registro1 = RegistroUsuarios::obterInstancia();
$registro1->adicionarUsuario('Usuário A', 'usuarioA@exemplo.com');
$registro1->adicionarUsuario('Usuário B', 'usuarioB@exemplo.com');

$registro2 = RegistroUsuarios::obterInstancia();
$registro2->adicionarUsuario('Usuário C', 'usuarioC@exemplo.com');
$registro2->adicionarUsuario('Usuário D', 'usuarioD@exemplo.com');

// Listando usuários das duas instâncias
$usuariosRegistrados1 = $registro1->listarUsuarios();
$usuariosRegistrados2 = $registro2->listarUsuarios();

echo "Usuários do registro 1:\n";
print_r($usuariosRegistrados1);

echo "Usuários do registro 2:\n";
print_r($usuariosRegistrados2);
?>
